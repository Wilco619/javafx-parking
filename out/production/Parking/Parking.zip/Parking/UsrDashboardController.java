package Parking;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class UsrDashboardController implements Initializable {

    @FXML
    private Label welcome_lbl;
    @FXML
    private Label usrName_lbl;

    @FXML
    private Button logout_btn;

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle){
        logout_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dbHandler.changeScene(event, "Dashboard1.fxml", "Log In!",null);

            }
        });
    }

    public void setUserInformation(String usrName){
        usrName_lbl.setText("Welcome " + usrName + "!");
    }
}
