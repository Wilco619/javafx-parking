package Parking;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class dbHandler {

    static void changeScene(ActionEvent event, String fxmlFile, String title, String usrName) {
        Parent root = null;

        if (usrName != null){
            try{
                FXMLLoader loader = new FXMLLoader(dbHandler.class.getResource(fxmlFile));
                root = loader.load();
                UsrDashboardController usrDashboardController = loader.getController();
                usrDashboardController.setUserInformation(usrName);
            }catch (IOException e){
                e.printStackTrace();
            }
        }else {
            try{
                root = FXMLLoader.load(dbHandler.class.getResource(fxmlFile));
            }catch (IOException e){
                e.printStackTrace();
            }
        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.centerOnScreen();
        stage.show();

    }

    public static void signUpUser(ActionEvent event,String name, String usrName, String email, Integer phone, String password, String passwordRepeat) {
        Connection connection = null;
        PreparedStatement psInsert = null;
        PreparedStatement psCheckUserExists = null;
        ResultSet resultSet = null;

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/PsignUp","root","");
            psCheckUserExists = connection.prepareStatement("SELECT * FROM signUp WHERE usrName = ? AND email = ?");
            psCheckUserExists.setString(1,usrName);
            psCheckUserExists.setString(2,email);
            resultSet = psCheckUserExists.executeQuery();

            if (resultSet.isBeforeFirst()){
                System.out.println("User Already Exist!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Please Use a different User Name");
                alert.show();
            }else{
                psInsert = connection.prepareStatement("INSERT INTO signUp (name, usrName, email, phone, password, passwordRepeat) VALUES (?, ?, ?, ?, ?, ?)");
                psInsert.setString(1,name);
                psInsert.setString(2,usrName);
                psInsert.setString(3,email);
                psInsert.setInt(4,phone);
                psInsert.setString(5,password);
                psInsert.setString(6,passwordRepeat);
                psInsert.executeUpdate();

//                changeScene(event, "UsrDashboard.fxml", "Welcome", usrName);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }finally {
            if (resultSet != null){
                try{
                    resultSet.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if (psCheckUserExists != null){
                try{
                    psCheckUserExists.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if (psInsert != null){
                try{
                    psInsert.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if (connection != null){
                try{
                    connection.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
        }
    }
    public static void logInUser(ActionEvent event, String usrName, String password){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/PsignUp","root","");
            preparedStatement = connection.prepareStatement("SELECT password, email FROM signUp WHERE usrName = ?");
            preparedStatement.setString(1,usrName);
            resultSet = preparedStatement.executeQuery();

            if (!resultSet.isBeforeFirst()){
                System.out.println("User not Found!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Incorrect User Name Or Password!");
                alert.show();
            }else{
                while(resultSet.next()){
                    String retrievePassword = resultSet.getString("password");
                    if (retrievePassword.equals(password)){
                        changeScene(event, "UsrDashboard.fxml","Welcome!", usrName);
                    }else {
                        System.out.println("Passwords did not match!");
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setContentText("Incorrect User Name Or Password!");
                        alert.show();
                    }
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            if (resultSet != null){
                try{
                    resultSet.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if (connection != null){
                try{
                    connection.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null){
                try {
                    preparedStatement.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
        }
    }


}