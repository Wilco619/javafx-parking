package Parking;

public class Admin {
}
