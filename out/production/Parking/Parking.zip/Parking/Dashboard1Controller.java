package Parking;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Dashboard1Controller implements Initializable {

    @FXML
    private TextField loginUsrName;

    @FXML
    private PasswordField loginPwd;

    @FXML
    private Label correctDetails;

    @FXML
    private Label labelForgot;

    @FXML
    private Button logIn_btn;
    @FXML
    private Button signUp_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        logIn_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dbHandler.logInUser(event, loginUsrName.getText(), loginPwd.getText());
            }
        });
        signUp_btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dbHandler.changeScene(event, "SignUp.fxml","Sign Up!",null);
            }
        });
    }
}